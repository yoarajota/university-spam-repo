# Precisa ter typescript instalado
# Precisa ter uma string de conexão ao MongoDB (Seja remoto ou local)

# npm i && npm run dev dentro da pasta frontend e backend

# Pode ser solicitado a instalação de algumas tipagens type @types/node no backends